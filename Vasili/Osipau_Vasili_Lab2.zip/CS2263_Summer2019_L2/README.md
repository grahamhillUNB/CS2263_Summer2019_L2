# CS2263_Summer2019_L2
# Modified by Graham Hill and Vasili Osipau
# The program sorts an array of integers.
# The program reads in the array size and its elements, then outputs the sorted array.
